<?php
// exit if direct aacessed
if (!defined('ABSPATH')) {
    exit;
}

// register menu page
function register_plugin_menu()
{
    add_menu_page('MR Like / Dislike Settings', 'Like System Settings', 'manage_options', 'mrld-settings', 'mrld_setting_structure', 'dashicons-thumbs-up', 30);
}
add_action('admin_menu', 'register_plugin_menu');

// plugin page html
function mrld_setting_structure()
{
    if (!is_admin()) {
        return;
}?>
<div class="wrap">
   <h1 style="background-color: #23282d; color: #eee; padding: 10px;"><?=esc_html(get_admin_page_title());?></h1>
   <form action="options.php" method="post">
        <?php
            settings_fields('mrld_label_settings');
            do_settings_sections('mrld_label_settings');

            settings_fields('mrld_message_settings');
            do_settings_sections('mrld_message_settings');

            submit_button('Save Changes');
        ?>
   </form>
</div>
<?php
}

// add plugin settings
function mrld_pluin_setting()
{
    // register settings sections
    register_setting('mrld_label_settings', 'total_label');
    register_setting('mrld_label_settings', 'btn_like_label');
    register_setting('mrld_label_settings', 'btn_dislike_label');
    
    register_setting('mrld_message_settings', 'like_message_field');
    register_setting('mrld_message_settings', 'dislike_message_field');
    register_setting('mrld_message_settings', 'login_message_field');

    // button label section
    add_settings_Section('mrld_label_settings_section', 'Button Labels', 'mrld_plugin_setting_section_cb', 'mrld_label_settings');
    
    // Message label section
    add_settings_Section('mrld_message_settings_section', 'Notification Messages', 'mrld_plugin_setting_messege_cb', 'mrld_message_settings');

    // add setting fields
    add_settings_field('mrld_total_label_input', 'Total Indicator Label', 'mrld_total_label_cb', 'mrld_label_settings', 'mrld_label_settings_section');
    add_settings_field('mrld_like_label_input', 'Like Button Text', 'mrld_like_label_cb', 'mrld_label_settings', 'mrld_label_settings_section');
    add_settings_field('mrld_dislike_label_input', 'Dislike Button Text', 'mrld_dislike_label_cb', 'mrld_label_settings', 'mrld_label_settings_section');
    
    add_settings_field('mrld_like_message_input', 'Like The Post', 'mrld_like_message_cb', 'mrld_message_settings', 'mrld_message_settings_section');
    add_settings_field('mrld_dislike_message_input', 'Dislike The Post', 'mrld_dislike_message_cb', 'mrld_message_settings', 'mrld_message_settings_section');
    add_settings_field('mrld_login_input', 'User Not Logged in', 'mrld_login_message_cb', 'mrld_message_settings', 'mrld_message_settings_section');
}
add_action('admin_init', 'mrld_pluin_setting');

// callback functions
function mrld_plugin_setting_section_cb()
{
    // echo "<p>Define Button labels</p>";
}
function mrld_plugin_setting_messege_cb()
{
    // echo "<p>Define Button labels</p>";
}

function mrld_total_label_cb()
{
    $totalLabelDB = get_option('total_label');?>
    <input type="text" name="total_label" value="<?php echo isset($totalLabelDB) ? esc_attr($totalLabelDB) : ''; ?>" />
<?php
}
function mrld_like_label_cb()
{
    $likeLabelDB = get_option('btn_like_label');?>
    <input type="text" name="btn_like_label" value="<?php echo isset($likeLabelDB) ? esc_attr($likeLabelDB) : ''; ?>" />
<?php
}
function mrld_dislike_label_cb()
{
    $dislikeLabelDB = get_option('btn_dislike_label');?>
    <input type="text" name="btn_dislike_label" value="<?php echo isset($dislikeLabelDB) ? esc_attr($dislikeLabelDB) : ''; ?>" />
<?php
}

function mrld_like_message_cb()
{
    $likeMessage = get_option('like_message_field');?>
    <input type="text" name="like_message_field" value="<?php echo isset($likeMessage) ? esc_attr($likeMessage) : ''; ?>" />
<?php
}
function mrld_dislike_message_cb()
{
    $dislikeMessage = get_option('dislike_message_field');?>
    <input type="text" name="dislike_message_field" value="<?php echo isset($dislikeMessage) ? esc_attr($dislikeMessage) : ''; ?>" />
<?php
}
function mrld_login_message_cb()
{
    $loginMessage = get_option('login_message_field');?>
    <input type="text" name="login_message_field" value="<?php echo isset($loginMessage) ? esc_attr($loginMessage) : ''; ?>" />
<?php
}
?>