<?php
/*
 * Plugin name: MR Like Dislike
 * Plugin url: https://mrtangle.com/plugins
 * Author name: MR
 * Author url: https://mrtangle.com
 * Version: 1.0.0
 * Description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente, odit.
 * Licence: GPL2
 * Text domain: mrld
 */

// exit if direct aacessed
if (!defined('ABSPATH')) {
    exit;
}

// define constant
if (!defined('MRLD_URL')) {
    define('MRLD_URL', plugin_dir_url(__FILE__));
}

// enqueue style and scripts
if (!function_exists('mrld_plugin_script')) {
    function mrld_plugin_scripts()
    {
        // font awesome css
        wp_enqueue_style('mrld-fa-style', MRLD_URL . 'assets/css/all.min.css');
        // plugin main style
        wp_enqueue_style('mrld-main-style', MRLD_URL . 'assets/css/main.css');

        // ajax js
        wp_enqueue_script('mrld-ajax-js', MRLD_URL . 'assets/js/like-ajax.js', 'jQuery', '1.0.0', true);
        // plugin main js
        wp_enqueue_script('mrld-main-js', MRLD_URL . 'assets/js/main.js', 'jQuery', '1.0.0', true);

        wp_localize_script('mrld-ajax-js', 'mrld_ajax_url', array(
            'ajax_url' => admin_url('admin-ajax.php'),
        ));
    }
    add_action('wp_enqueue_scripts', 'mrld_plugin_scripts');
}

// setting menu and page
require plugin_dir_path(__FILE__) . 'inc/plugin-settings.php';

// setting table
require plugin_dir_path(__FILE__) . 'inc/db.php';
register_activation_hook(__FILE__, 'mrld_like_table');

// add buttons to post
require plugin_dir_path(__FILE__) . 'inc/add_buttons.php';

// ajax data
require plugin_dir_path(__FILE__) . 'inc/like_ajax.php';