// like ajax call
function mrld_like_btn_ajax(postId, userId) {
   var post_id = postId;
   var user_id = userId;

   if (user_id == 0) {
      jQuery('#mrld_ajax_response').html('<span class="warning">Please login First.</span>');
      setTimeout(function () {
         jQuery('#mrld_ajax_response span').hide();
      }, 5000);
   } else {
      jQuery.ajax({
         url: mrld_ajax_url.ajax_url,
         type: 'post',
         data: {
            action: 'mrld_ajax_btn_like',
            pid: post_id,
            uid: user_id
         },
         success: function (response) {
            jQuery("#mrld_like_count_" + postId + userId).html(response.likes);
            jQuery("#mrld_dislike_count_" + postId + userId).html(response.dislikes);
            if (response.class && !jQuery("#mrld_like_btn_" + postId + userId).hasClass('applied')) {
               jQuery("#mrld_like_btn_" + postId + userId).addClass('applied');
               jQuery("#mrld_dislike_btn_" + postId + userId).removeClass('applied');
            }
            jQuery('#mrld_ajax_response').html(response.message);
            setTimeout(function () {
               jQuery('#mrld_ajax_response span').hide();
            }, 5000)
         }
      });
   }
}

// dislike ajax call
function mrld_dislike_btn_ajax(postId, userId) {
   var post_id = postId;
   var user_id = userId;

   if (user_id == 0) {
      jQuery('#mrld_ajax_response').html('<span class="warning">Please login First.</span>');
      setTimeout(function () {
         jQuery('#mrld_ajax_response span').hide();
      }, 5000);
   } else {
      jQuery.ajax({
         url: mrld_ajax_url.ajax_url,
         type: 'post',
         data: {
            action: 'mrld_ajax_btn_dislike',
            pid: post_id,
            uid: user_id
         },
         success: function (response) {
            jQuery("#mrld_like_count_" + postId + userId).html(response.likes);
            jQuery("#mrld_dislike_count_" + postId + userId).html(response.dislikes);
            if (response.class && !jQuery("#mrld_dislike_btn_" + postId + userId).hasClass('applied')) {
               jQuery("#mrld_dislike_btn_" + postId + userId).addClass('applied');
               jQuery("#mrld_like_btn_" + postId + userId).removeClass('applied');
            }
            jQuery('#mrld_ajax_response').html(response.message);
            setTimeout(function () {
               jQuery('#mrld_ajax_response span').hide();
            }, 5000)
         }
      });
   }
}