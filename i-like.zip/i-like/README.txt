=== I like ===
Requires at least: 4.0
Tested up to: 5.3.2
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

"I like" plugin will help you to add like and dislike functionality to your post, so you can easily monitor which posts are much liked or disliked by visitors.

== Description ==

"I like" plugin will help you to add like and dislike functionality to your post, so you can easily monitor which posts are much liked or disliked by visitors.

when people will visit your blog and find that useful they can react on your post without wasting time to write traditional comment. also you can monitor your post with total likes and dislikes.
you can customize like and dislike labels as your needs, also can use only icon button.

A few notes about the sections above:

*   Tags - "Like System", "like", "dislike", "reactions"
*   "Tested up to" 5.3.2

== Installation ==

Download the plugin, install and get your like-dislike buttons are visible to each of your post.

1. Go to `add new plugin` and click on `upload` button, select `i-like.zip` file from explorer.
2. Click on install button.
3. After install, activate the plugin
4. you can find settings under "I Like" menu in admin area.

== Frequently Asked Questions ==

= How to remove text from buttons =

Just leave fields blank for like and dislike button text in "I Like" setting page

== Screenshots ==

1. screenshot-1.jpg
2. screenshot-2.jpg

== Changelog ==

= 1.0 =
* Initial update.